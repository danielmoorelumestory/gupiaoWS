"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => KnowledgeSyncPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian2 = require("obsidian");
var import_node_path2 = require("node:path");

// ../server/knowledge/sync-contract.ts
var import_node_crypto = require("node:crypto");
var hash = (content) => (0, import_node_crypto.createHash)("sha256").update(content, "utf8").digest("hex");
var uuidPattern = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
var hashPattern = /^[a-f0-9]{64}$/;
function validatePaths(paths) {
  const files = /* @__PURE__ */ new Set(), segments = /* @__PURE__ */ new Map();
  for (const path of paths) {
    if (typeof path !== "string" || path.length > 500 || !path.endsWith(".md") || /[\\\x00-\x1f\x7f]/.test(path)) throw new Error("\u7B14\u8BB0\u8DEF\u5F84\u65E0\u6548");
    const parts = path.split("/");
    let full = "";
    for (const part of parts) {
      if (!part || part.startsWith(".") || /[<>:"|?*]/.test(part) || /[. ]$/.test(part) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part)) throw new Error("\u7B14\u8BB0\u8DEF\u5F84\u4E0D\u517C\u5BB9");
      full = full ? `${full}/${part}` : part;
      const canonical2 = full.normalize("NFC").toUpperCase().toLowerCase().normalize("NFC");
      if (segments.has(canonical2) && segments.get(canonical2) !== full) throw new Error("\u8DEF\u5F84\u5B58\u5728\u5927\u5C0F\u5199\u6216 Unicode \u51B2\u7A81");
      segments.set(canonical2, full);
    }
    if (parts.slice(0, -1).some((p) => p.toLowerCase().endsWith(".md"))) throw new Error("\u7B14\u8BB0\u4E0D\u80FD\u4F5C\u4E3A\u6587\u4EF6\u5939");
    if (parts[0].toLowerCase() === "sync-conflicts") throw new Error("\u51B2\u7A81\u76EE\u5F55\u4E0D\u80FD\u81EA\u52A8\u540C\u6B65");
    const canonical = path.normalize("NFC").toUpperCase().toLowerCase().normalize("NFC");
    if (files.has(canonical)) throw new Error("\u7B14\u8BB0\u8DEF\u5F84\u91CD\u590D");
    files.add(canonical);
  }
  for (const path of paths) {
    const parts = path.split("/");
    parts.pop();
    while (parts.length) {
      if (files.has(parts.join("/").normalize("NFC").toUpperCase().toLowerCase().normalize("NFC"))) throw new Error("\u7B14\u8BB0\u4E0E\u6587\u4EF6\u5939\u8DEF\u5F84\u51B2\u7A81");
      parts.pop();
    }
  }
}
function validateNotes(notes, max = 1e4) {
  if (!Array.isArray(notes) || notes.length > max) throw new Error("\u7B14\u8BB0\u6570\u91CF\u65E0\u6548");
  for (const note of notes) {
    if (!note || typeof note.path !== "string" || typeof note.content !== "string" || typeof note.version !== "string" || Buffer.byteLength(note.content) > 1024 * 1024 || !hashPattern.test(note.version) || hash(note.content) !== note.version) throw new Error("\u7B14\u8BB0\u6B63\u6587\u6216 SHA-256 \u6821\u9A8C\u5931\u8D25");
  }
  validatePaths(notes.map((n) => n.path));
  return notes.map(({ path, content, version }) => ({ path, content, version }));
}
function validateHead(head) {
  const h = head;
  if (!h || !Number.isSafeInteger(h.revision) || h.revision < 0 || h.generation !== null && (typeof h.generation !== "string" || !uuidPattern.test(h.generation)) || h.vaultId !== null && (typeof h.vaultId !== "string" || !hashPattern.test(h.vaultId)) || h.generation === null !== (h.vaultId === null)) throw new Error("\u4E91\u7AEF\u7248\u672C\u65E0\u6548");
  return { revision: h.revision, generation: h.generation, vaultId: h.vaultId };
}

// ../knowledge-sync/transport.ts
var RemoteError = class extends Error {
  constructor(status2) {
    super(`\u4E91\u7AEF\u540C\u6B65\u8BF7\u6C42\u5931\u8D25 (${status2})`);
    this.status = status2;
  }
  status;
};
function createRemote(endpoint, token, http = async (url, init) => {
  const r = await fetch(url, { ...init, redirect: "error" });
  return { status: r.status, body: await r.json() };
}) {
  const u = new URL(endpoint);
  if (u.protocol !== "https:" || u.username || u.password || u.search || u.hash || u.pathname !== "/api/knowledge" || token.length < 32) throw new Error("\u9700\u8981 HTTPS /api/knowledge \u5730\u5740\u548C\u6709\u6548\u540C\u6B65\u51ED\u636E");
  const request2 = async (action, params = {}, body) => {
    const url = new URL(u);
    url.searchParams.set("action", action);
    for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
    const r = await http(url.href, { method: body === void 0 ? "GET" : "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, body: body === void 0 ? void 0 : JSON.stringify(body), signal: AbortSignal.timeout(3e4) });
    if (r.status < 200 || r.status >= 300) throw new RemoteError(r.status);
    return r.body;
  };
  return {
    head: async () => validateHead(await request2("sync-head")),
    manifest: async (head, cursor) => await request2("sync-manifest", { generation: head.generation, ...cursor ? { cursor } : {} }),
    read: async (head, path) => validateNotes([await request2("sync-note", { generation: head.generation, path })])[0],
    publish: async (expectedHead, notes, generation, vaultId) => {
      validateNotes(notes);
      let batch = [];
      const send = () => request2("sync-batch", {}, { generation, vaultId, notes: batch });
      for (const note of notes) {
        if (batch.length && (batch.length === 100 || Buffer.byteLength(JSON.stringify({ generation, vaultId, notes: [...batch, note] })) > 27e5)) {
          await send();
          batch = [];
        }
        batch.push(note);
      }
      if (batch.length) await send();
      return validateHead(await request2("sync-commit", {}, { generation, vaultId, expectedHead, count: notes.length }));
    }
  };
}
async function downloadSnapshot(remote, head) {
  validateHead(head);
  if (!head.generation) return /* @__PURE__ */ new Map();
  const entries = [];
  let cursor = null, total;
  const seen = /* @__PURE__ */ new Set();
  do {
    const page = await remote.manifest(head, cursor);
    if (JSON.stringify(validateHead(page.head)) !== JSON.stringify(head) || !Array.isArray(page.notes) || page.notes.length > 200 || !Number.isInteger(page.total) || page.total < 0 || page.total > 1e4 || total !== void 0 && total !== page.total) throw new Error("\u5FEB\u7167\u6E05\u5355\u4E0D\u5B8C\u6574");
    total = page.total;
    for (const note of page.notes) {
      if (typeof note.path !== "string" || !hashPattern.test(note.version)) throw new Error("\u6E05\u5355\u65E0\u6548");
      if (seen.has(note.path)) throw new Error("\u6E05\u5355\u91CD\u590D");
      seen.add(note.path);
      entries.push(note);
    }
    if (entries.length > total) throw new Error("\u6E05\u5355\u6570\u91CF\u65E0\u6548");
    const next = page.nextCursor;
    if (next !== null && (typeof next !== "string" || !page.notes.length || next !== page.notes.at(-1)?.path || next === cursor)) throw new Error("\u5206\u9875\u6E38\u6807\u65E0\u6548");
    cursor = next;
  } while (cursor !== null);
  if (entries.length !== total) throw new Error("\u6E05\u5355\u6570\u91CF\u4E0D\u5B8C\u6574");
  validatePaths(entries.map((n) => n.path));
  const notes = /* @__PURE__ */ new Map();
  let index = 0;
  await Promise.all(Array.from({ length: Math.min(4, entries.length) }, async () => {
    while (index < entries.length) {
      const entry = entries[index++], note = await remote.read(head, entry.path);
      validateNotes([note]);
      if (note.path !== entry.path || note.version !== entry.version) throw new Error("\u7B14\u8BB0\u4E0E\u5FEB\u7167\u7248\u672C\u4E0D\u4E00\u81F4");
      notes.set(note.path, note);
    }
  }));
  return new Map([...notes].sort(([a], [b]) => a.localeCompare(b)));
}

// ../knowledge-sync/engine.ts
var import_node_crypto2 = require("node:crypto");

// ../knowledge-sync/merge.ts
function mergeNotes(base, local, remote) {
  const paths = [.../* @__PURE__ */ new Set([...base.keys(), ...local.keys(), ...remote.keys()])].sort();
  validatePaths(paths);
  const merged = /* @__PURE__ */ new Map(), conflicts = [];
  const same = (a, b) => a?.version === b?.version;
  for (const path of paths) {
    const b = base.get(path), l = local.get(path), r = remote.get(path);
    let next;
    if (same(l, r)) next = l;
    else if (same(l, b)) next = r;
    else if (same(r, b)) next = l;
    else {
      conflicts.push({ path, local: l ?? null, remote: r ?? null });
      next = l;
    }
    if (next) merged.set(path, next);
  }
  return { merged, conflicts };
}

// ../knowledge-sync/engine.ts
var map = (notes) => new Map(validateNotes(notes).map((n) => [n.path, n]));
var equal = (a, b) => a.size === b.size && [...a].every(([p, n]) => b.get(p)?.version === n.version);
var status = (state) => ({ status: state.conflicts.length ? "conflict" : "synced", conflicts: state.conflicts.map((c) => c.path), head: state.head });
async function applyPending(vault, state) {
  const p = state.pending;
  const before = map(p.before), target = map(p.notes), current = await vault.list();
  validateNotes([...current.values()]);
  const safe = new Map(current);
  const conflicts = [...state.conflicts];
  for (const path of /* @__PURE__ */ new Set([...before.keys(), ...target.keys(), ...current.keys()])) {
    const b = before.get(path), t = target.get(path), c = current.get(path);
    if (c?.version === b?.version || c?.version === t?.version) {
      if (t) safe.set(path, t);
      else safe.delete(path);
    } else if (t?.version !== b?.version) conflicts.push({ path, local: c ?? null, remote: t ?? null });
  }
  await vault.preserveConflicts(conflicts);
  await vault.apply(current, safe);
  const next = { ...state, head: p.targetHead ?? p.expectedHead, baseline: p.baseline, pending: null, conflicts };
  await vault.saveState(next);
  return next;
}
async function syncOnce(remote, vault) {
  let state = await vault.loadState();
  if (state) {
    validateHead(state.head);
    map(state.baseline);
    if (state.pending) {
      map(state.pending.notes);
      map(state.pending.before);
      map(state.pending.baseline);
    }
  }
  if (state?.pending) {
    const p = state.pending;
    if (p.kind === "publish") {
      const acceptedHead = { revision: p.expectedHead.revision + 1, generation: p.generation, vaultId: p.vaultId };
      let accepted = false;
      try {
        const saved = await downloadSnapshot(remote, acceptedHead);
        if (!equal(saved, map(p.notes))) throw new Error("\u5DF2\u53D1\u5E03\u5FEB\u7167\u5185\u5BB9\u4E0D\u4E00\u81F4");
        accepted = true;
      } catch (e) {
        if (e.status !== 404) throw e;
      }
      if (!accepted) {
        const now = await remote.head();
        if (JSON.stringify(now) === JSON.stringify(p.expectedHead)) p.targetHead = await remote.publish(p.expectedHead, p.notes, p.generation, p.vaultId);
        else {
          state = { ...state, pending: null };
          await vault.saveState(state);
        }
      } else p.targetHead = acceptedHead;
    }
    if (state.pending) {
      state = await applyPending(vault, state);
      return status(state);
    }
  }
  if (state?.conflicts.length) return status(state);
  for (let attempt = 0; attempt < 3; attempt++) {
    const head = validateHead(await remote.head());
    if (state?.head.vaultId && state.head.vaultId !== head.vaultId) throw new Error("\u670D\u52A1\u7AEF\u8D44\u6599\u5E93\u8EAB\u4EFD\u6539\u53D8\uFF0C\u8BF7\u8FDE\u63A5\u72EC\u7ACB\u4ED3\u5E93");
    const remoteNotes = await downloadSnapshot(remote, head), local = await vault.list();
    validateNotes([...local.values()]);
    const plan = mergeNotes(state ? map(state.baseline) : /* @__PURE__ */ new Map(), local, remoteNotes);
    if (plan.conflicts.length) {
      await vault.preserveConflicts(plan.conflicts);
      state = { head: state?.head ?? head, vaultId: state?.vaultId ?? head.vaultId ?? hash((0, import_node_crypto2.randomUUID)()), baseline: state?.baseline ?? [], pending: null, conflicts: plan.conflicts };
      await vault.saveState(state);
      return status(state);
    }
    const first = state === null;
    const vaultId = state?.vaultId ?? head.vaultId ?? hash((0, import_node_crypto2.randomUUID)());
    const publish = !first && !equal(plan.merged, remoteNotes);
    const pending = { kind: publish ? "publish" : "apply", generation: publish ? (0, import_node_crypto2.randomUUID)() : head.generation, vaultId, expectedHead: head, targetHead: publish ? null : head, notes: [...plan.merged.values()], before: [...local.values()], baseline: [...(publish ? plan.merged : remoteNotes).values()] };
    state = { head: state?.head ?? head, vaultId, baseline: state?.baseline ?? [], pending, conflicts: [] };
    await vault.saveState(state);
    if (publish) {
      try {
        pending.targetHead = await remote.publish(head, pending.notes, pending.generation, vaultId);
      } catch (e) {
        if (e.status === 409) {
          state = { ...state, pending: null };
          await vault.saveState(state);
          continue;
        }
        throw e;
      }
    }
    state = await applyPending(vault, state);
    return status(state);
  }
  throw new Error("\u5176\u4ED6\u8BBE\u5907\u6301\u7EED\u4FEE\u6539\uFF0C\u8BF7\u7A0D\u540E\u518D\u540C\u6B65");
}

// src/vault-adapter.ts
var import_node_crypto3 = require("node:crypto");
var import_promises = require("node:fs/promises");
var import_node_path = require("node:path");
var ObsidianVaultAdapter = class {
  constructor(vault, root, directory, signal) {
    this.vault = vault;
    this.root = root;
    this.directory = directory;
    this.signal = signal;
  }
  vault;
  root;
  directory;
  signal;
  async guard(full) {
    if (this.signal?.aborted) throw new Error("\u540C\u6B65\u5DF2\u505C\u6B62");
    const root = (0, import_node_path.resolve)(this.root), rel = (0, import_node_path.relative)(root, (0, import_node_path.resolve)(full));
    if (rel.startsWith(`..${import_node_path.sep}`) || rel === ".." || (0, import_node_path.resolve)(full) === root) throw new Error("\u4E0D\u80FD\u64CD\u4F5C\u4ED3\u5E93\u5916\u6587\u4EF6");
    let current = root;
    for (const segment of ["", ...rel.split(import_node_path.sep)]) {
      if (segment) current = (0, import_node_path.join)(current, segment);
      try {
        const s = await (0, import_promises.lstat)(current);
        if (s.isSymbolicLink()) throw new Error("\u4E0D\u652F\u6301\u7B26\u53F7\u94FE\u63A5");
      } catch (e) {
        if (e.code !== "ENOENT") throw e;
      }
    }
  }
  async list() {
    await this.recoverDeletion();
    const notes = [];
    for (const file of this.vault.getMarkdownFiles()) {
      if (file.path.split("/")[0].toLowerCase() === "sync-conflicts") continue;
      await this.guard((0, import_node_path.join)(this.root, file.path));
      const content = await this.vault.read(file);
      notes.push({ path: file.path, content, version: hash(content) });
    }
    return new Map(validateNotes(notes).map((n) => [n.path, n]));
  }
  async loadState() {
    const file = (0, import_node_path.join)(this.directory, "sync-state.json");
    await this.guard(file);
    try {
      return JSON.parse(await (0, import_promises.readFile)(file, "utf8"));
    } catch (e) {
      if (e.code === "ENOENT") return null;
      throw new Error("\u540C\u6B65\u72B6\u6001\u65E0\u6CD5\u8BFB\u53D6\uFF0C\u5DF2\u505C\u6B62\u540C\u6B65\u4EE5\u4FDD\u62A4\u7B14\u8BB0");
    }
  }
  async saveState(state) {
    const file = (0, import_node_path.join)(this.directory, "sync-state.json");
    await this.guard(file);
    await (0, import_promises.mkdir)(this.directory, { recursive: true, mode: 448 });
    const temp = file + ".tmp";
    await this.guard(temp);
    await (0, import_promises.writeFile)(temp, JSON.stringify(state), { mode: 384 });
    await (0, import_promises.rename)(temp, file);
  }
  async folders(path) {
    const segments = path.split("/");
    segments.pop();
    let dir = "";
    for (const segment of segments) {
      dir = dir ? `${dir}/${segment}` : segment;
      await this.guard((0, import_node_path.join)(this.root, dir));
      if (!this.vault.getAbstractFileByPath(dir)) {
        try {
          await this.vault.createFolder(dir);
        } catch (e) {
          if (!this.vault.getAbstractFileByPath(dir)) throw e;
        }
      }
    }
  }
  async apply(before, target) {
    validateNotes([...before.values()]);
    validateNotes([...target.values()]);
    validatePaths([.../* @__PURE__ */ new Set([...before.keys(), ...target.keys()])]);
    const changes = [.../* @__PURE__ */ new Set([...before.keys(), ...target.keys()])].filter((p) => before.get(p)?.version !== target.get(p)?.version);
    for (const path of changes) {
      await this.guard((0, import_node_path.join)(this.root, path));
      const file = this.vault.getAbstractFileByPath(path);
      const current = file && file.extension === "md" ? hash(await this.vault.read(file)) : void 0;
      if (current !== before.get(path)?.version || file && !file.extension) throw new Error(`\u7B14\u8BB0\u5DF2\u53D8\u66F4\uFF0C\u8BF7\u91CD\u65B0\u540C\u6B65\uFF1A${path}`);
    }
    for (const path of changes) {
      await this.guard((0, import_node_path.join)(this.root, path));
      const file = this.vault.getAbstractFileByPath(path), note = target.get(path), expected = before.get(path)?.version;
      if (file) {
        if (file.extension !== "md") throw new Error("\u8DEF\u5F84\u88AB\u6587\u4EF6\u5939\u5360\u7528");
        await this.vault.process(file, (content) => {
          if (hash(content) !== expected) throw new Error(`\u7B14\u8BB0\u5DF2\u53D8\u66F4\uFF1A${path}`);
          return note?.content ?? content;
        });
        if (!note) await this.safeDelete(file, expected);
      } else if (note) {
        if (expected !== void 0) throw new Error(`\u7B14\u8BB0\u5DF2\u5220\u9664\uFF1A${path}`);
        await this.folders(path);
        await this.vault.create(path, note.content);
      }
    }
  }
  async writeDeletion(value) {
    const file = (0, import_node_path.join)(this.directory, "delete-journal.json");
    await this.guard(file);
    await (0, import_promises.mkdir)(this.directory, { recursive: true, mode: 448 });
    const temp = file + ".tmp";
    await this.guard(temp);
    await (0, import_promises.writeFile)(temp, JSON.stringify(value), { mode: 384 });
    await (0, import_promises.rename)(temp, file);
  }
  async recoverDeletion() {
    const journal = (0, import_node_path.join)(this.directory, "delete-journal.json");
    await this.guard(journal);
    let entry;
    try {
      entry = JSON.parse(await (0, import_promises.readFile)(journal, "utf8"));
    } catch (e) {
      if (e.code === "ENOENT") return;
      throw e;
    }
    if (!entry) return;
    validatePaths([entry.path]);
    if (!/^\.trash\/businessweb-sync-[a-f0-9-]+\.md$/.test(entry.backup)) throw new Error("\u5220\u9664\u6062\u590D\u65E5\u5FD7\u65E0\u6548");
    const full = (0, import_node_path.join)(this.root, entry.backup);
    await this.guard(full);
    let content;
    try {
      content = await (0, import_promises.readFile)(full, "utf8");
    } catch (e) {
      if (e.code === "ENOENT") {
        await this.writeDeletion(null);
        return;
      }
      throw e;
    }
    if (hash(content) !== entry.version) {
      await this.guard((0, import_node_path.join)(this.root, entry.path));
      const existing = this.vault.getAbstractFileByPath(entry.path);
      if (!existing) {
        await this.folders(entry.path);
        await this.vault.create(entry.path, content);
      } else if (existing.extension === "md") await this.preserveConflicts([{ path: entry.path, local: { path: entry.path, content, version: hash(content) }, remote: { path: entry.path, content: await this.vault.read(existing), version: hash(await this.vault.read(existing)) } }]);
      else throw new Error("\u7F16\u8F91\u5185\u5BB9\u4FDD\u5B58\u5728\u56DE\u6536\u7AD9\uFF0C\u539F\u8DEF\u5F84\u5DF2\u88AB\u5360\u7528");
      await this.writeDeletion(null);
      throw new Error(`\u5220\u9664\u671F\u95F4\u7B14\u8BB0\u88AB\u7F16\u8F91\uFF0C\u5DF2\u4FDD\u7559\u65B0\u5185\u5BB9\uFF1A${entry.path}`);
    }
    await this.writeDeletion(null);
  }
  async safeDelete(file, version) {
    const original = file.path, backup = `.trash/businessweb-sync-${(0, import_node_crypto3.randomUUID)()}.md`;
    await this.guard((0, import_node_path.join)(this.root, backup));
    await (0, import_promises.mkdir)((0, import_node_path.join)(this.root, ".trash"), { recursive: true, mode: 448 });
    await this.writeDeletion({ path: original, backup, version });
    await this.vault.rename(file, backup);
    await this.recoverDeletion();
  }
  async preserveConflicts(conflicts) {
    for (const conflict of conflicts) {
      const stem = conflict.path.split("/").pop().slice(0, 50).replace(/[^\p{L}\p{N}._-]/gu, "_"), id = hash(conflict.path).slice(0, 12);
      for (const side of ["local", "remote"]) {
        const note = conflict[side], content = note?.content ?? `# \u540C\u6B65\u51B2\u7A81\uFF1A\u6B64\u7248\u672C\u5DF2\u5220\u9664

\u539F\u8DEF\u5F84\uFF1A${conflict.path}
`;
        const path = `Sync-Conflicts/${stem}-${id}-${hash(content).slice(0, 12)}-${side}.md`;
        await this.guard((0, import_node_path.join)(this.root, path));
        await this.folders(path);
        const existing = this.vault.getAbstractFileByPath(path);
        if (existing) {
          if (existing.extension !== "md" || hash(await this.vault.read(existing)) !== hash(content)) throw new Error("\u51B2\u7A81\u526F\u672C\u8DEF\u5F84\u88AB\u5360\u7528");
          continue;
        }
        await this.vault.create(path, content);
      }
    }
  }
  async resolveConflict(path, choice) {
    const state = await this.loadState();
    if (!state || state.pending) throw new Error("\u5B58\u5728\u5F85\u6062\u590D\u540C\u6B65\u4E8B\u52A1");
    const conflict = state.conflicts.find((c) => c.path === path);
    if (!conflict) throw new Error("\u51B2\u7A81\u5DF2\u5904\u7406");
    const current = await this.list();
    if (choice === "remote") {
      const target = new Map(current);
      if (conflict.remote) target.set(path, conflict.remote);
      else target.delete(path);
      await this.apply(current, target);
    }
    const base = new Map(state.baseline.map((n) => [n.path, n]));
    if (conflict.remote) base.set(path, conflict.remote);
    else base.delete(path);
    state.baseline = [...base.values()];
    state.conflicts = state.conflicts.filter((c) => c.path !== path);
    await this.saveState(state);
  }
};

// src/scheduler.ts
var SyncScheduler = class {
  constructor(run, delay = 2e3) {
    this.run = run;
    this.delay = delay;
  }
  run;
  delay;
  timer = null;
  running = null;
  stopped = false;
  changed() {
    if (this.stopped || this.running) return;
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.timer = null;
      void this.now().catch(() => {
      });
    }, this.delay);
  }
  async now() {
    if (this.stopped) return;
    if (this.running) return this.running;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.running = Promise.resolve().then(() => this.run());
    try {
      await this.running;
    } finally {
      this.running = null;
    }
  }
  async exclusive(action) {
    while (this.running) await this.running.catch(() => {
    });
    if (this.stopped) return;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.running = Promise.resolve().then(action);
    try {
      await this.running;
    } finally {
      this.running = null;
    }
  }
  stop() {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }
};

// src/native-http.ts
var import_node_https = require("node:https");
function nativeHttp(parent) {
  return (url, init) => new Promise((resolve2, reject) => {
    const req = (0, import_node_https.request)(url, { method: init.method, headers: init.headers, signal: AbortSignal.any([parent, init.signal]) }, (res) => {
      const status2 = res.statusCode ?? 0;
      if (status2 >= 300 && status2 < 400) {
        res.resume();
        reject(new Error("\u670D\u52A1\u5668\u91CD\u5B9A\u5411\u5DF2\u62D2\u7EDD"));
        return;
      }
      const chunks = [];
      let bytes = 0;
      res.on("data", (chunk) => {
        bytes += chunk.length;
        if (bytes > 3e6) {
          req.destroy(new Error("\u670D\u52A1\u5668\u54CD\u5E94\u8FC7\u5927"));
          return;
        }
        chunks.push(chunk);
      });
      res.on("error", reject);
      res.on("end", () => {
        try {
          resolve2({ status: status2, body: JSON.parse(Buffer.concat(chunks).toString("utf8")) });
        } catch {
          reject(new Error("\u670D\u52A1\u5668\u54CD\u5E94\u683C\u5F0F\u65E0\u6548"));
        }
      });
    });
    req.on("error", () => reject(new Error(parent.aborted ? "\u540C\u6B65\u5DF2\u505C\u6B62" : "\u670D\u52A1\u5668\u8FDE\u63A5\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC")));
    if (init.body) req.write(init.body);
    req.end();
  });
}

// src/settings.ts
var import_obsidian = require("obsidian");
var defaults = { endpoint: "https://business-web-black.vercel.app/api/knowledge", syncToken: "", enabled: false, boundEndpoint: "" };
var SyncSettingsTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  plugin;
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "\u81EA\u5DF1\u7684\u670D\u52A1\u5668 \xB7 \u77E5\u8BC6\u540C\u6B65" });
    containerEl.createEl("p", { text: "\u4EC5\u7B14\u8BB0\u540C\u6B65\uFF0C\u56FE\u7247/PDF \u5C1A\u672A\u540C\u6B65\u3002\u65B0\u7535\u8111\u9996\u6B21\u8FDE\u63A5\u5148\u4E0B\u8F7D\uFF1B\u5B8C\u6210\u540E\u81EA\u52A8\u540C\u6B65\u4FEE\u6539\u3002" });
    new import_obsidian.Setting(containerEl).setName("\u670D\u52A1\u5668\u5730\u5740").addText((t) => t.setValue(this.plugin.settings.endpoint).onChange(async (value) => {
      this.plugin.settings.endpoint = value.trim();
      await this.plugin.saveSettings();
    }));
    new import_obsidian.Setting(containerEl).setName("\u540C\u6B65\u51ED\u636E").setDesc("\u4F7F\u7528\u670D\u52A1\u5668\u7684 KNOWLEDGE_SYNC_TOKEN\u3002\u51ED\u636E\u4FDD\u5B58\u5728\u672C\u673A\u63D2\u4EF6 data.json\uFF0C\u8BF7\u52FF\u5206\u4EAB\u6B64\u6587\u4EF6\uFF1B\u5B83\u4E0D\u53C2\u4E0E\u7B14\u8BB0\u540C\u6B65\u3002").addText((t) => {
      t.inputEl.type = "password";
      t.setValue(this.plugin.settings.syncToken).onChange(async (value) => {
        this.plugin.settings.syncToken = value.trim();
        await this.plugin.saveSettings();
      });
    });
    new import_obsidian.Setting(containerEl).setName("\u6D4B\u8BD5\u8FDE\u63A5").addButton((b) => b.setButtonText("\u6D4B\u8BD5").onClick(async () => {
      try {
        const revision = await this.plugin.testConnection();
        new import_obsidian.Notice(`\u8FDE\u63A5\u6210\u529F\uFF0C\u670D\u52A1\u5668\u7248\u672C ${revision}`);
      } catch (e) {
        new import_obsidian.Notice(e instanceof Error ? e.message : "\u8FDE\u63A5\u5931\u8D25");
      }
    }));
    new import_obsidian.Setting(containerEl).setName("\u81EA\u52A8\u540C\u6B65").setDesc("\u6BCF 30 \u79D2\u68C0\u67E5\u670D\u52A1\u5668\uFF0C\u4FEE\u6539\u7B14\u8BB0\u540E\u81EA\u52A8\u540C\u6B65\u3002").addToggle((t) => t.setValue(this.plugin.settings.enabled).onChange(async (value) => {
      this.plugin.settings.enabled = value;
      await this.plugin.saveSettings();
      if (value) void this.plugin.scheduler.now().catch(() => {
      });
    }));
    new import_obsidian.Setting(containerEl).setName("\u7ACB\u5373\u540C\u6B65").addButton((b) => b.setButtonText("\u540C\u6B65").onClick(async () => {
      if (!this.plugin.settings.enabled) {
        new import_obsidian.Notice("\u8BF7\u5148\u542F\u7528\u81EA\u52A8\u540C\u6B65");
        return;
      }
      await this.plugin.scheduler.now().catch(() => {
      });
      this.display();
    }));
    void this.showConflicts(containerEl);
  }
  async showConflicts(container) {
    try {
      const state = await this.plugin.adapter.loadState();
      for (const c of state?.conflicts ?? []) {
        new import_obsidian.Setting(container).setName(c.path).setDesc("\u53CC\u65B9\u5185\u5BB9\u4FDD\u5B58\u5728 Sync-Conflicts\uFF1B\u5148\u9605\u8BFB\u526F\u672C\uFF0C\u518D\u9009\u62E9\u4FDD\u7559\u54EA\u4E00\u7248\u3002").addButton((b) => b.setButtonText("\u4FDD\u7559\u672C\u5730").onClick(async () => {
          try {
            await this.plugin.scheduler.exclusive(() => this.plugin.adapter.resolveConflict(c.path, "local"));
            this.display();
          } catch (e) {
            new import_obsidian.Notice(String(e));
          }
        })).addButton((b) => b.setButtonText("\u91C7\u7528\u670D\u52A1\u5668").onClick(async () => {
          try {
            await this.plugin.scheduler.exclusive(() => this.plugin.adapter.resolveConflict(c.path, "remote"));
            this.display();
          } catch (e) {
            new import_obsidian.Notice(String(e));
          }
        }));
      }
    } catch {
      container.createEl("p", { text: "\u540C\u6B65\u72B6\u6001\u4E0D\u53EF\u8BFB\uFF0C\u5DF2\u505C\u6B62\u4EE5\u4FDD\u62A4\u7B14\u8BB0\u3002" });
    }
  }
};

// src/main.ts
var KnowledgeSyncPlugin = class extends import_obsidian2.Plugin {
  settings = { ...defaults };
  adapter;
  scheduler;
  abort = new AbortController();
  status;
  async onload() {
    this.settings = { ...defaults, ...await this.loadData() };
    if (!(this.app.vault.adapter instanceof import_obsidian2.FileSystemAdapter)) {
      new import_obsidian2.Notice("\u6B64\u540C\u6B65\u63D2\u4EF6\u76EE\u524D\u652F\u6301\u684C\u9762\u7535\u8111");
      return;
    }
    const v = this.app.vault;
    const file = (ref) => {
      const f = v.getAbstractFileByPath(ref.path);
      if (!(f instanceof import_obsidian2.TFile)) throw new Error("\u7B14\u8BB0\u8DEF\u5F84\u5DF2\u6539\u53D8");
      return f;
    };
    const io = { getMarkdownFiles: () => v.getMarkdownFiles(), getAbstractFileByPath: (p) => v.getAbstractFileByPath(p), read: (r) => v.read(file(r)), process: (r, fn) => v.process(file(r), fn), create: (p, c) => v.create(p, c), createFolder: (p) => v.createFolder(p), trash: (r, system) => v.trash(file(r), system), rename: (r, p) => v.rename(file(r), p) };
    this.adapter = new ObsidianVaultAdapter(io, this.app.vault.adapter.getBasePath(), (0, import_node_path2.join)(this.app.vault.adapter.getBasePath(), this.manifest.dir), this.abort.signal);
    this.status = this.addStatusBarItem();
    this.status.setText("\u77E5\u8BC6\u540C\u6B65\uFF1A\u7B49\u5F85\u8FDE\u63A5");
    this.scheduler = new SyncScheduler(() => this.synchronize(), 2e3);
    this.addSettingTab(new SyncSettingsTab(this.app, this));
    this.addCommand({ id: "sync-now", name: "\u7ACB\u5373\u540C\u6B65\u77E5\u8BC6\u5E93", callback: () => {
      void this.scheduler.now().catch(() => {
      });
    } });
    this.addRibbonIcon("refresh-cw", "\u540C\u6B65\u77E5\u8BC6\u5E93", () => {
      void this.scheduler.now().catch(() => {
      });
    });
    for (const event of ["create", "modify", "delete", "rename"]) this.registerEvent(v.on(event, () => this.scheduler.changed()));
    this.registerInterval(window.setInterval(() => {
      void this.scheduler.now().catch(() => {
      });
    }, 3e4));
    this.app.workspace.onLayoutReady(() => {
      if (this.settings.enabled) void this.scheduler.now().catch(() => {
      });
    });
  }
  async testConnection() {
    return (await createRemote(this.settings.endpoint, this.settings.syncToken, nativeHttp(this.abort.signal)).head()).revision;
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  async synchronize() {
    if (!this.settings.enabled || !this.settings.syncToken) return;
    this.status.setText("\u77E5\u8BC6\u540C\u6B65\uFF1A\u540C\u6B65\u4E2D");
    try {
      const binding = this.settings.endpoint.trim();
      if (this.settings.boundEndpoint && this.settings.boundEndpoint !== binding) throw new Error("\u670D\u52A1\u5668\u5730\u5740\u5DF2\u6539\u53D8\uFF0C\u8BF7\u4F7F\u7528\u72EC\u7ACB\u4ED3\u5E93\u8FDE\u63A5");
      const remote = createRemote(binding, this.settings.syncToken, nativeHttp(this.abort.signal));
      const result = await syncOnce(remote, this.adapter);
      this.settings.boundEndpoint = binding;
      await this.saveSettings();
      this.status.setText(result.status === "conflict" ? `\u77E5\u8BC6\u540C\u6B65\uFF1A${result.conflicts.length} \u5904\u51B2\u7A81` : `\u77E5\u8BC6\u540C\u6B65\uFF1A\u5DF2\u540C\u6B65 \xB7 v${result.head?.revision ?? 0}`);
      if (result.status === "conflict") new import_obsidian2.Notice("\u6709\u540C\u6B65\u51B2\u7A81\uFF0C\u53CC\u65B9\u5185\u5BB9\u5DF2\u4FDD\u7559\u3002\u8BF7\u5728\u77E5\u8BC6\u540C\u6B65\u8BBE\u7F6E\u4E2D\u5904\u7406\u3002");
    } catch (e) {
      this.status.setText("\u77E5\u8BC6\u540C\u6B65\uFF1A\u8FDE\u63A5\u6216\u540C\u6B65\u5931\u8D25");
      new import_obsidian2.Notice(e instanceof Error ? e.message : "\u540C\u6B65\u5931\u8D25");
      throw e;
    }
  }
  onunload() {
    this.scheduler?.stop();
    this.abort.abort();
  }
};
